--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Homebrew)
-- Dumped by pg_dump version 14.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: sasakitakumi
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE postgres OWNER TO sasakitakumi;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: sasakitakumi
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO sasakitakumi;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO sasakitakumi;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO sasakitakumi;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO sasakitakumi;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO sasakitakumi;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO sasakitakumi;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO sasakitakumi;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO sasakitakumi;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO sasakitakumi;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO sasakitakumi;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO sasakitakumi;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO sasakitakumi;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO sasakitakumi;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO sasakitakumi;

--
-- Name: mistake_follow; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.mistake_follow (
    id integer NOT NULL,
    date_created timestamp with time zone NOT NULL,
    followed_id integer NOT NULL,
    following_id integer NOT NULL
);


ALTER TABLE public.mistake_follow OWNER TO sasakitakumi;

--
-- Name: mistake_follow_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.mistake_follow_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mistake_follow_id_seq OWNER TO sasakitakumi;

--
-- Name: mistake_follow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.mistake_follow_id_seq OWNED BY public.mistake_follow.id;


--
-- Name: mistake_like; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.mistake_like (
    id integer NOT NULL,
    like_flag boolean NOT NULL,
    post_id_id integer NOT NULL,
    user_id_id integer NOT NULL
);


ALTER TABLE public.mistake_like OWNER TO sasakitakumi;

--
-- Name: mistake_like_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.mistake_like_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mistake_like_id_seq OWNER TO sasakitakumi;

--
-- Name: mistake_like_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.mistake_like_id_seq OWNED BY public.mistake_like.id;


--
-- Name: mistake_post; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.mistake_post (
    id integer NOT NULL,
    categories character varying(50) NOT NULL,
    text text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    delete_flag integer NOT NULL,
    like_count integer NOT NULL,
    user_id integer NOT NULL,
    post_mixed double precision,
    post_negative double precision,
    post_neutral double precision,
    post_positive double precision
);


ALTER TABLE public.mistake_post OWNER TO sasakitakumi;

--
-- Name: mistake_post_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.mistake_post_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mistake_post_id_seq OWNER TO sasakitakumi;

--
-- Name: mistake_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.mistake_post_id_seq OWNED BY public.mistake_post.id;


--
-- Name: mistake_user; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.mistake_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(50) NOT NULL,
    nickname character varying(50) NOT NULL,
    email character varying(254),
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    image character varying(100)
);


ALTER TABLE public.mistake_user OWNER TO sasakitakumi;

--
-- Name: mistake_user_groups; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.mistake_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.mistake_user_groups OWNER TO sasakitakumi;

--
-- Name: mistake_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.mistake_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mistake_user_groups_id_seq OWNER TO sasakitakumi;

--
-- Name: mistake_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.mistake_user_groups_id_seq OWNED BY public.mistake_user_groups.id;


--
-- Name: mistake_user_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.mistake_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mistake_user_id_seq OWNER TO sasakitakumi;

--
-- Name: mistake_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.mistake_user_id_seq OWNED BY public.mistake_user.id;


--
-- Name: mistake_user_user_permissions; Type: TABLE; Schema: public; Owner: sasakitakumi
--

CREATE TABLE public.mistake_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.mistake_user_user_permissions OWNER TO sasakitakumi;

--
-- Name: mistake_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: sasakitakumi
--

CREATE SEQUENCE public.mistake_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mistake_user_user_permissions_id_seq OWNER TO sasakitakumi;

--
-- Name: mistake_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sasakitakumi
--

ALTER SEQUENCE public.mistake_user_user_permissions_id_seq OWNED BY public.mistake_user_user_permissions.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: mistake_follow id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_follow ALTER COLUMN id SET DEFAULT nextval('public.mistake_follow_id_seq'::regclass);


--
-- Name: mistake_like id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_like ALTER COLUMN id SET DEFAULT nextval('public.mistake_like_id_seq'::regclass);


--
-- Name: mistake_post id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_post ALTER COLUMN id SET DEFAULT nextval('public.mistake_post_id_seq'::regclass);


--
-- Name: mistake_user id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user ALTER COLUMN id SET DEFAULT nextval('public.mistake_user_id_seq'::regclass);


--
-- Name: mistake_user_groups id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_groups ALTER COLUMN id SET DEFAULT nextval('public.mistake_user_groups_id_seq'::regclass);


--
-- Name: mistake_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.mistake_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3755.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3757.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3753.dat';

--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.
COPY public.authtoken_token (key, created, user_id) FROM '$$PATH$$/3773.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3771.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3751.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3749.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3772.dat';

--
-- Data for Name: mistake_follow; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.mistake_follow (id, date_created, followed_id, following_id) FROM stdin;
\.
COPY public.mistake_follow (id, date_created, followed_id, following_id) FROM '$$PATH$$/3769.dat';

--
-- Data for Name: mistake_like; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.mistake_like (id, like_flag, post_id_id, user_id_id) FROM stdin;
\.
COPY public.mistake_like (id, like_flag, post_id_id, user_id_id) FROM '$$PATH$$/3767.dat';

--
-- Data for Name: mistake_post; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.mistake_post (id, categories, text, created_at, updated_at, delete_flag, like_count, user_id, post_mixed, post_negative, post_neutral, post_positive) FROM stdin;
\.
COPY public.mistake_post (id, categories, text, created_at, updated_at, delete_flag, like_count, user_id, post_mixed, post_negative, post_neutral, post_positive) FROM '$$PATH$$/3765.dat';

--
-- Data for Name: mistake_user; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.mistake_user (id, password, last_login, is_superuser, username, nickname, email, is_staff, is_active, date_joined, image) FROM stdin;
\.
COPY public.mistake_user (id, password, last_login, is_superuser, username, nickname, email, is_staff, is_active, date_joined, image) FROM '$$PATH$$/3759.dat';

--
-- Data for Name: mistake_user_groups; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.mistake_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.mistake_user_groups (id, user_id, group_id) FROM '$$PATH$$/3761.dat';

--
-- Data for Name: mistake_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: sasakitakumi
--

COPY public.mistake_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.mistake_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3763.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 44, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 24, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 11, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 33, true);


--
-- Name: mistake_follow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.mistake_follow_id_seq', 4, true);


--
-- Name: mistake_like_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.mistake_like_id_seq', 7, true);


--
-- Name: mistake_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.mistake_post_id_seq', 33, true);


--
-- Name: mistake_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.mistake_user_groups_id_seq', 1, false);


--
-- Name: mistake_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.mistake_user_id_seq', 7, true);


--
-- Name: mistake_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sasakitakumi
--

SELECT pg_catalog.setval('public.mistake_user_user_permissions_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: mistake_follow mistake_follow_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_follow
    ADD CONSTRAINT mistake_follow_pkey PRIMARY KEY (id);


--
-- Name: mistake_like mistake_like_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_like
    ADD CONSTRAINT mistake_like_pkey PRIMARY KEY (id);


--
-- Name: mistake_post mistake_post_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_post
    ADD CONSTRAINT mistake_post_pkey PRIMARY KEY (id);


--
-- Name: mistake_user mistake_user_email_key; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user
    ADD CONSTRAINT mistake_user_email_key UNIQUE (email);


--
-- Name: mistake_user_groups mistake_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_groups
    ADD CONSTRAINT mistake_user_groups_pkey PRIMARY KEY (id);


--
-- Name: mistake_user_groups mistake_user_groups_user_id_group_id_ce6c6578_uniq; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_groups
    ADD CONSTRAINT mistake_user_groups_user_id_group_id_ce6c6578_uniq UNIQUE (user_id, group_id);


--
-- Name: mistake_user mistake_user_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user
    ADD CONSTRAINT mistake_user_pkey PRIMARY KEY (id);


--
-- Name: mistake_user_user_permissions mistake_user_user_permis_user_id_permission_id_ca2b5872_uniq; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_user_permissions
    ADD CONSTRAINT mistake_user_user_permis_user_id_permission_id_ca2b5872_uniq UNIQUE (user_id, permission_id);


--
-- Name: mistake_user_user_permissions mistake_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_user_permissions
    ADD CONSTRAINT mistake_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: mistake_user mistake_user_username_key; Type: CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user
    ADD CONSTRAINT mistake_user_username_key UNIQUE (username);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: mistake_follow_followed_id_23c8d669; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_follow_followed_id_23c8d669 ON public.mistake_follow USING btree (followed_id);


--
-- Name: mistake_follow_following_id_5140e1a8; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_follow_following_id_5140e1a8 ON public.mistake_follow USING btree (following_id);


--
-- Name: mistake_like_post_id_id_410d90ca; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_like_post_id_id_410d90ca ON public.mistake_like USING btree (post_id_id);


--
-- Name: mistake_like_user_id_id_250cd14e; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_like_user_id_id_250cd14e ON public.mistake_like USING btree (user_id_id);


--
-- Name: mistake_post_user_id_aefac273; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_post_user_id_aefac273 ON public.mistake_post USING btree (user_id);


--
-- Name: mistake_user_email_516f9f11_like; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_user_email_516f9f11_like ON public.mistake_user USING btree (email varchar_pattern_ops);


--
-- Name: mistake_user_groups_group_id_e75c2f5f; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_user_groups_group_id_e75c2f5f ON public.mistake_user_groups USING btree (group_id);


--
-- Name: mistake_user_groups_user_id_10539d5c; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_user_groups_user_id_10539d5c ON public.mistake_user_groups USING btree (user_id);


--
-- Name: mistake_user_user_permissions_permission_id_d7a65d9f; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_user_user_permissions_permission_id_d7a65d9f ON public.mistake_user_user_permissions USING btree (permission_id);


--
-- Name: mistake_user_user_permissions_user_id_d5862a2e; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_user_user_permissions_user_id_d5862a2e ON public.mistake_user_user_permissions USING btree (user_id);


--
-- Name: mistake_user_username_7fc4097c_like; Type: INDEX; Schema: public; Owner: sasakitakumi
--

CREATE INDEX mistake_user_username_7fc4097c_like ON public.mistake_user USING btree (username varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_mistake_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_mistake_user_id FOREIGN KEY (user_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_mistake_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_mistake_user_id FOREIGN KEY (user_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_follow mistake_follow_followed_id_23c8d669_fk_mistake_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_follow
    ADD CONSTRAINT mistake_follow_followed_id_23c8d669_fk_mistake_user_id FOREIGN KEY (followed_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_follow mistake_follow_following_id_5140e1a8_fk_mistake_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_follow
    ADD CONSTRAINT mistake_follow_following_id_5140e1a8_fk_mistake_user_id FOREIGN KEY (following_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_like mistake_like_post_id_id_410d90ca_fk_mistake_post_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_like
    ADD CONSTRAINT mistake_like_post_id_id_410d90ca_fk_mistake_post_id FOREIGN KEY (post_id_id) REFERENCES public.mistake_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_like mistake_like_user_id_id_250cd14e_fk_mistake_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_like
    ADD CONSTRAINT mistake_like_user_id_id_250cd14e_fk_mistake_user_id FOREIGN KEY (user_id_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_post mistake_post_user_id_aefac273_fk_mistake_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_post
    ADD CONSTRAINT mistake_post_user_id_aefac273_fk_mistake_user_id FOREIGN KEY (user_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_user_groups mistake_user_groups_group_id_e75c2f5f_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_groups
    ADD CONSTRAINT mistake_user_groups_group_id_e75c2f5f_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_user_groups mistake_user_groups_user_id_10539d5c_fk_mistake_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_groups
    ADD CONSTRAINT mistake_user_groups_user_id_10539d5c_fk_mistake_user_id FOREIGN KEY (user_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_user_user_permissions mistake_user_user_pe_permission_id_d7a65d9f_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_user_permissions
    ADD CONSTRAINT mistake_user_user_pe_permission_id_d7a65d9f_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mistake_user_user_permissions mistake_user_user_pe_user_id_d5862a2e_fk_mistake_u; Type: FK CONSTRAINT; Schema: public; Owner: sasakitakumi
--

ALTER TABLE ONLY public.mistake_user_user_permissions
    ADD CONSTRAINT mistake_user_user_pe_user_id_d5862a2e_fk_mistake_u FOREIGN KEY (user_id) REFERENCES public.mistake_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

